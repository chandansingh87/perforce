var searchData=
[
  ['sortinputs_0',['sortInputs',['../classp_logic.html#ad944dab857268fa2ff7472429fb40111',1,'pLogic']]]
];
