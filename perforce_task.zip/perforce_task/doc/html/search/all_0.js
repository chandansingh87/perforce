var searchData=
[
  ['addintime_0',['addInTime',['../classp_logic.html#ad09d8458d6c07d10fb2334a968832b1b',1,'pLogic']]],
  ['addouttime_1',['addOutTime',['../classp_logic.html#a88704e59e0702d977c10ca710b9d067a',1,'pLogic']]]
];
