var searchData=
[
  ['getendinterval_0',['getEndInterval',['../classp_logic.html#a72be53e449677385ad14e1c64d508c4e',1,'pLogic']]],
  ['getmaxvisitor_1',['getMaxVisitor',['../classp_logic.html#a734ef5d273acab0c453e8cc4e31bca55',1,'pLogic']]],
  ['getnoofvisitors_2',['getNoOfVisitors',['../classp_logic.html#a83a37678513b298e95f2d72019fe280b',1,'pLogic']]],
  ['getstinterval_3',['getStInterval',['../classp_logic.html#acc974b2182fd32e24b9a772f6f69cffc',1,'pLogic']]]
];
