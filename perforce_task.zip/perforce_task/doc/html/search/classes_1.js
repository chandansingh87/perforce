var searchData=
[
  ['plogic_0',['pLogic',['../classp_logic.html',1,'']]]
];
