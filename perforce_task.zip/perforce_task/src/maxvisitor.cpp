#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <vector>

using namespace std;

/**
 * defines some generic error
 */
enum {
	NO_ERROR = 0,
	PARSE_ERROR,
	INTERNAL_ERROR
};
/**
 * Class which is responsible for all logical computation of the problem statement,
 */
class pLogic {

	std::vector<int> m_inTime;
	std::vector<int> m_outTime;
	int m_noOfVisitors;
	int m_stInterval;
	int m_endInterval;
	/**
	* converts a 4 digit number to string hh:min format
	*/
	std::string convert(int time) {
		int t = time;
		int m = t % 10;
		t = t / 10;

		int n = t % 10;

		t = t / 10;

		int min = n * 10 + m;

		std::string r = std::to_string(t) + ":" + std::to_string(min);
		return r;

	}
public:

	/**
	* function which adds in time of visitor in a vector
	*/
	void addInTime(int time) { m_inTime.emplace_back(time); }
	/**
	* function which adds out time of visitor in a vector
	*/
	void addOutTime(int time) { m_outTime.emplace_back(time); }
	/**
	* function which returns max number of visitor at a time
	*/
	int getNoOfVisitors() { return m_noOfVisitors; }
	/**
	* function which returns time when there was max visitor in hh:mm format
	*/
	string getStInterval() { return convert(m_stInterval); }
	/**
	* function which returns time when a visitor exits after we had max visitor in hh:mm format
	*/
	string getEndInterval() { return convert(m_endInterval); }

	/**
	* sorts in time and out time vectors in ascending order
	*/
	void sortInputs() {

		std::sort(m_inTime.begin(), m_inTime.end());
		std::sort(m_outTime.begin(), m_outTime.end());
	}
	/**
	* Logic which computes no of visitor at any point of time
	*/
	int getMaxVisitor() {

		int rc = NO_ERROR;
		int noOfVisitorIn = 1;
		m_noOfVisitors = noOfVisitorIn;
		m_stInterval = m_inTime[0];

		int i = 1, j = 0;
		int N = m_inTime.size();

		while (i < N && j < N) {

			if (m_inTime[i] <= m_outTime[j]) {

				noOfVisitorIn++;
				if (noOfVisitorIn > m_noOfVisitors) {
					m_noOfVisitors = noOfVisitorIn;
					m_stInterval = m_inTime[i];
				}
				i++;
			}
			else {
				if (noOfVisitorIn == m_noOfVisitors) {
					m_endInterval = m_outTime[j];
				}
				noOfVisitorIn--;
				j++;
			}
		}
		return rc;
	}
};
/**
 * Class which parses the input file and writes in and out time
 */
class iParser {
	pLogic* m_inputObj;

	/**
	* parse the in/out time, converts it to integer value(hh:mm to hhmm)
	*/
	int t_FillTime(std::string str, int st) {

		int rc = NO_ERROR;
		size_t found = str.find(":");
		if (found != string::npos) {
			std::string hour = str.substr(0, found);
			std::string mins = str.substr(found + 1, str.length());

			int h = atoi(hour.c_str());
			int min = atoi(mins.c_str());

			int num = h * 100 + min;

			(st == 0) ? m_inputObj->addInTime(num) : m_inputObj->addOutTime(num);
		}
		else {
			rc = PARSE_ERROR;
		}
		return rc;

	}
public:

	iParser() = delete;
	iParser(const iParser& obj) = delete;
	iParser(pLogic* iPtr) : m_inputObj(iPtr) {}

	/**
	* parse and prepare in and out vector which will be used in traversal and contruction of program logic
	*/
	int Parse(std::string inputStr) {

		int rc = NO_ERROR;
		size_t found = inputStr.find(",");

		if (found != string::npos) {

			std::string first = inputStr.substr(0, found);
			std::string second = inputStr.substr(found + 1, inputStr.length());

			rc = t_FillTime(first, 0);
			if (rc) { return rc; }

			rc = t_FillTime(second, 1);
			if (rc) { return rc; }
		}
		else {
			rc = PARSE_ERROR;
		}
		return rc;
	}
};

int main() {

	int rc = NO_ERROR;

	std::string inputfilepath;
	cout << "Enter the path of input file" << endl;
	cin >> inputfilepath;
	ifstream file(inputfilepath);

	if (file.is_open()) {
		std::string line;
		pLogic pObj;
		iParser iObj(&pObj);

		while (getline(file, line)) {
			iObj.Parse(line);
		}

		pObj.sortInputs();

		if (rc = pObj.getMaxVisitor()) {
			cout << "internal error, rc = " << rc << endl;
		}
		else {
			cout << pObj.getStInterval() << "-" << pObj.getEndInterval() << ";" << pObj.getNoOfVisitors() << endl;
		}
		file.close();
	}
	return rc;

}