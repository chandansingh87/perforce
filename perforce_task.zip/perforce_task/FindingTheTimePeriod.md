Solution :
We sort the in time and out time array using the standard sorting algorithim which will result in O(n*logn) time complexity.

Now we traverse input arrays and execute below condition based logic.

j = 0, i = 1
currentvisitor = 1, maxvisitor = currentvisitor
stTimeInterval = in[0]
endTimeInterval = out[0]
while i < N and j < N

	if in[i] <= out[j]
		- increment currentvisitor
		- if currentvisitor is greater than maxvisitor, update maxvisitor and sttimeInterval 
		- increment i
	else		
		- if currentvisitor is equal to maxvisitor, update endTimeInterval 
		/*This is done to capture the time when a visitor exits at a point of time when we had maxvisitor */
		- decrement currentvisitor
		- increment j
		
Hence total time complexity is n + n*logn
		
	